(UTF8 encoding)

*********************************************************************************************
V2.03 : 2021/08/09 

- Added the function that extract from multiple image files at once.
*********************************************************************************************
V2.02 : 2021/06/05 

- Supports Japanesw Horizontal 2 page writing split by center space.
- Supports Japanese Vertical 2 page writing.(4 page for left and right)
- Setup option is added to extract header/footer line separatedly
  to avoid which may be mixed with body text.
*********************************************************************************************
V2.01 : 2020/01/27 (1st release)

This tool generates text file extracting image document file.
(Function to easily correct mis-recognition is added to previos version:VBOCR)  
Expand zip file, then open SetupVBOCR2.msi to install.

Windows app "Windows Fax and Scan" can be used to create image file. 

Requirement:"Microsoft OCR Library for Windows" is used,
            it requires Windows10 Novenber Update(2015/11:Version 1511).

GitHub sakachin2/VBOCR2 contains MSVS2017Community project source

Please send your suggestion or bug reports to mail:sakachin2@yahoo.co.jp

